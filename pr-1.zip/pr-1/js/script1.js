function sumofBoundary(matrix) {
    let sum = 0;
    const rows = matrix.length;
    console.log(rows,'row');
    const cols = matrix[0].length;

    for (let i = 0; i < cols; i++) {
        sum += matrix[0][i];//[0][0]=1
        sum += matrix[rows - 1][i];//(2-1)=[1][1]  1+2
    }


    for (let i = 1; i < rows - 1; i++) {
        sum += matrix[i][0];//[1][0]=2
        sum += matrix[i][cols - 1];//(2-1)=[1][1]  1+2+3+4
    }


    return sum;
}

const matrix = [
    [1, 2],
    [3, 4]
   
];

const boundarySum = sumofBoundary(matrix);
console.log("Sum of boundary elements:", boundarySum);