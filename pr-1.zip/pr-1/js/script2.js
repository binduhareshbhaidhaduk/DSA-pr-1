function mergeArrByColumns(array1, array2) {

    let mergedArr = [];
    for (let i = 0; i < array1.length; i++) {
        mergedArr.push(array1[i].concat(array2[i]));
    }

    return mergedArr;
}

const array1 = [
    [1, 2],
    [3, 4]
];

const array2 = [
    [5, 6],
    [7, 8]
];

const mergedByColumns = mergeArrByColumns(array1, array2);
console.log("Merge by columns:", mergedByColumns);


