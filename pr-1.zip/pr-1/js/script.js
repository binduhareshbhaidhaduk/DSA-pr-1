const arr1 = [[1, 2], [3, 4]];
const arr2 = [[5, 6], [7, 8]];

function sumofArr(arr1, arr2) {


    let newArr = [];

    for (let i = 0; i < arr1.length; i++) {
        newArr[i] = [];
        console.log('he',newArr);
        for (let j = 0; j < arr1[i].length; j++) {
            newArr[i][j] = arr1[i][j] + arr2[i][j];
        }
    }

    return newArr;
}

const resultArr = sumofArr(arr1, arr2);
console.log(resultArr);
