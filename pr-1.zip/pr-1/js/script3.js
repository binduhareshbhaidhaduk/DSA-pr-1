function findMaxAndMinValue(mat) {
    if (!mat || mat.length === 0 || mat[0].length === 0) {
        return null;
    }

    let maxValue = mat[0][0];
    let minValue = mat[0][0];

    for (let i = 0; i < mat.length; i++) {
        for (let j = 0; j < mat[i].length; j++) {
            if (mat[i][j] > maxValue) {//[0][0]>maxValue
                maxValue = mat[i][j];//1>2 1>3 1>4 2>3 2>4 3>4
            }
            if (mat[i][j] < minValue) {
                minValue = mat[i][j];//1<2 1<3 1<4 2<3 2<4 3<4
            }
        }
    }

    return { max: maxValue, min: minValue };
}

const mat = [
    [1, 2 ],
    [3, 4 ]
];

const result = findMaxAndMinValue(mat);
console.log("Minimum value:", result.min); //  Min 1
console.log("Maximum value:", result.max); //  Max 4
